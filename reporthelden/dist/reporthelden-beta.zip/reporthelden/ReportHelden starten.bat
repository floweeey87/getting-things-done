@echo off
cd /d "%~dp0"

py -3 --version >nul 2>nul
if %errorlevel%==0 (
  py -3 app.py
  goto ende
)

python --version >nul 2>nul
if %errorlevel%==0 (
  python app.py
  goto ende
)

echo.
echo   Python wurde auf diesem Rechner nicht gefunden.
echo.
echo   1. https://www.python.org/downloads/ oeffnen
echo   2. Python 3 installieren - WICHTIG: beim Installieren den Haken
echo      bei "Add python.exe to PATH" setzen
echo   3. Diese Datei danach erneut doppelklicken
echo.

:ende
echo.
pause
