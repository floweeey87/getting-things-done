#!/bin/bash
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo
  echo "  Python 3 wurde nicht gefunden."
  echo "  Auf dem Mac ist es normalerweise dabei — sonst hier laden:"
  echo "  https://www.python.org/downloads/"
  echo
  read -n 1 -s -r -p "  Taste drücken zum Schließen ..."
  exit 1
fi

python3 app.py || {
  echo
  read -n 1 -s -r -p "  Es ist ein Fehler aufgetreten. Taste drücken zum Schließen ..."
}
